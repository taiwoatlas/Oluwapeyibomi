const ARCHIVE_MANIFEST = [
  {
    "id": "july-01",
    "category": "july",
    "categoryLabel": "July Memories",
    "file": "july-01.jpg",
    "caption": "Finally warm enough to wear shorts. The legs are out this summer.Swipe to see mo\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "july-02",
    "category": "july",
    "categoryLabel": "July Memories",
    "file": "july-02.jpg",
    "caption": "Finally warm enough to wear shorts. The legs are out this summer.Swipe to see mo\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "july-03",
    "category": "july",
    "categoryLabel": "July Memories",
    "file": "july-03.jpg",
    "caption": "Finally warm enough to wear shorts. The legs are out this summer.Swipe to see mo\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "july-04",
    "category": "july",
    "categoryLabel": "July Memories",
    "file": "july-04.jpg",
    "caption": "Finally warm enough to wear shorts. The legs are out this summer.Swipe to see mo\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "july-05",
    "category": "july",
    "categoryLabel": "July Memories",
    "file": "july-05.jpg",
    "caption": "Finally warm enough to wear shorts. The legs are out this summer.Swipe to see mo\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "july-06",
    "category": "july",
    "categoryLabel": "July Memories",
    "file": "july-06.jpg",
    "caption": "Finally warm enough to wear shorts. The legs are out this summer.Swipe to see mo\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "july-07",
    "category": "july",
    "categoryLabel": "July Memories",
    "file": "july-07.jpg",
    "caption": "Finally warm enough to wear shorts. The legs are out this summer.Swipe to see mo\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "july-08",
    "category": "july",
    "categoryLabel": "July Memories",
    "file": "july-08.jpg",
    "caption": "Finally warm enough to wear shorts. The legs are out this summer.Swipe to see mo\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "july-09",
    "category": "july",
    "categoryLabel": "July Memories",
    "file": "july-09.jpg",
    "caption": "Finally warm enough to wear shorts. The legs are out this summer.Swipe to see mo\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "july-10",
    "category": "july",
    "categoryLabel": "July Memories",
    "file": "july-10.jpg",
    "caption": "Finally warm enough to wear shorts. The legs are out this summer.Swipe to see mo\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1433
  },
  {
    "id": "july-11",
    "category": "july",
    "categoryLabel": "July Memories",
    "file": "july-11.jpg",
    "caption": "Finally warm enough to wear shorts. The legs are out this summer.Swipe to see mo\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "july-12",
    "category": "july",
    "categoryLabel": "July Memories",
    "file": "july-12.jpg",
    "caption": "Finally warm enough to wear shorts. The legs are out this summer.Swipe to see mo\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "july-13",
    "category": "july",
    "categoryLabel": "July Memories",
    "file": "july-13.jpg",
    "caption": "Finally warm enough to wear shorts. The legs are out this summer.Swipe to see mo\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "life20s-01",
    "category": "life20s",
    "categoryLabel": "Life in My 20s",
    "file": "life20s-01.jpg",
    "caption": "With counting down to year 3.0, these days I have been doing a lot of self r\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1440
  },
  {
    "id": "life20s-02",
    "category": "life20s",
    "categoryLabel": "Life in My 20s",
    "file": "life20s-02.jpg",
    "caption": "With counting down to year 3.0, these days I have been doing a lot of self r\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1440
  },
  {
    "id": "life20s-03",
    "category": "life20s",
    "categoryLabel": "Life in My 20s",
    "file": "life20s-03.jpg",
    "caption": "With counting down to year 3.0, these days I have been doing a lot of self r\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1440
  },
  {
    "id": "life20s-04",
    "category": "life20s",
    "categoryLabel": "Life in My 20s",
    "file": "life20s-04.jpg",
    "caption": "With counting down to year 3.0, these days I have been doing a lot of self r\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1440
  },
  {
    "id": "life20s-05",
    "category": "life20s",
    "categoryLabel": "Life in My 20s",
    "file": "life20s-05.jpg",
    "caption": "With counting down to year 3.0, these days I have been doing a lot of self r\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1440
  },
  {
    "id": "life20s-06",
    "category": "life20s",
    "categoryLabel": "Life in My 20s",
    "file": "life20s-06.jpg",
    "caption": "With counting down to year 3.0, these days I have been doing a lot of self r\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1440
  },
  {
    "id": "life20s-07",
    "category": "life20s",
    "categoryLabel": "Life in My 20s",
    "file": "life20s-07.jpg",
    "caption": "With counting down to year 3.0, these days I have been doing a lot of self r\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1440
  },
  {
    "id": "cameraroll-01",
    "category": "cameraroll",
    "categoryLabel": "Camera Roll",
    "file": "cameraroll-01.jpg",
    "caption": "Remember when we just posted on IG and went about our day without overthinking, no\u2026",
    "orientation": "square",
    "w": 1170,
    "h": 1170
  },
  {
    "id": "cameraroll-02",
    "category": "cameraroll",
    "categoryLabel": "Camera Roll",
    "file": "cameraroll-02.jpg",
    "caption": "Remember when we just posted on IG and went about our day without overthinking, no\u2026",
    "orientation": "square",
    "w": 1170,
    "h": 1170
  },
  {
    "id": "cameraroll-03",
    "category": "cameraroll",
    "categoryLabel": "Camera Roll",
    "file": "cameraroll-03.jpg",
    "caption": "Remember when we just posted on IG and went about our day without overthinking, no\u2026",
    "orientation": "square",
    "w": 1170,
    "h": 1170
  },
  {
    "id": "cameraroll-04",
    "category": "cameraroll",
    "categoryLabel": "Camera Roll",
    "file": "cameraroll-04.jpg",
    "caption": "Remember when we just posted on IG and went about our day without overthinking, no\u2026",
    "orientation": "square",
    "w": 1170,
    "h": 1170
  },
  {
    "id": "cameraroll-05",
    "category": "cameraroll",
    "categoryLabel": "Camera Roll",
    "file": "cameraroll-05.jpg",
    "caption": "Remember when we just posted on IG and went about our day without overthinking, no\u2026",
    "orientation": "square",
    "w": 1170,
    "h": 1170
  },
  {
    "id": "cameraroll-06",
    "category": "cameraroll",
    "categoryLabel": "Camera Roll",
    "file": "cameraroll-06.jpg",
    "caption": "Remember when we just posted on IG and went about our day without overthinking, no\u2026",
    "orientation": "square",
    "w": 1170,
    "h": 1170
  },
  {
    "id": "cameraroll-07",
    "category": "cameraroll",
    "categoryLabel": "Camera Roll",
    "file": "cameraroll-07.jpg",
    "caption": "Remember when we just posted on IG and went about our day without overthinking, no\u2026",
    "orientation": "square",
    "w": 1170,
    "h": 1170
  },
  {
    "id": "cameraroll-08",
    "category": "cameraroll",
    "categoryLabel": "Camera Roll",
    "file": "cameraroll-08.jpg",
    "caption": "Remember when we just posted on IG and went about our day without overthinking, no\u2026",
    "orientation": "square",
    "w": 1170,
    "h": 1170
  },
  {
    "id": "cameraroll-09",
    "category": "cameraroll",
    "categoryLabel": "Camera Roll",
    "file": "cameraroll-09.jpg",
    "caption": "Remember when we just posted on IG and went about our day without overthinking, no\u2026",
    "orientation": "square",
    "w": 1170,
    "h": 1170
  },
  {
    "id": "career-01",
    "category": "career",
    "categoryLabel": "Career",
    "file": "career-01.jpg",
    "caption": "These are some tips which have accelerated my career growth as a lady in her 2\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1440
  },
  {
    "id": "career-02",
    "category": "career",
    "categoryLabel": "Career",
    "file": "career-02.jpg",
    "caption": "These are some tips which have accelerated my career growth as a lady in her 2\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1440
  },
  {
    "id": "career-03",
    "category": "career",
    "categoryLabel": "Career",
    "file": "career-03.jpg",
    "caption": "These are some tips which have accelerated my career growth as a lady in her 2\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1440
  },
  {
    "id": "career-04",
    "category": "career",
    "categoryLabel": "Career",
    "file": "career-04.jpg",
    "caption": "These are some tips which have accelerated my career growth as a lady in her 2\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1440
  },
  {
    "id": "career-05",
    "category": "career",
    "categoryLabel": "Career",
    "file": "career-05.jpg",
    "caption": "These are some tips which have accelerated my career growth as a lady in her 2\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1440
  },
  {
    "id": "career-06",
    "category": "career",
    "categoryLabel": "Career",
    "file": "career-06.jpg",
    "caption": "These are some tips which have accelerated my career growth as a lady in her 2\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1440
  },
  {
    "id": "career-07",
    "category": "career",
    "categoryLabel": "Career",
    "file": "career-07.jpg",
    "caption": "These are some tips which have accelerated my career growth as a lady in her 2\u2026",
    "orientation": "portrait",
    "w": 1080,
    "h": 1440
  },
  {
    "id": "softlife-01",
    "category": "softlife",
    "categoryLabel": "Soft Life",
    "file": "softlife-01.jpg",
    "caption": "IN JPEGS1-14 Not a morning person but trying to smile2-14 At my favourite heal\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "softlife-02",
    "category": "softlife",
    "categoryLabel": "Soft Life",
    "file": "softlife-02.jpg",
    "caption": "IN JPEGS1-14 Not a morning person but trying to smile2-14 At my favourite heal\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "softlife-03",
    "category": "softlife",
    "categoryLabel": "Soft Life",
    "file": "softlife-03.jpg",
    "caption": "IN JPEGS1-14 Not a morning person but trying to smile2-14 At my favourite heal\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "softlife-04",
    "category": "softlife",
    "categoryLabel": "Soft Life",
    "file": "softlife-04.jpg",
    "caption": "IN JPEGS1-14 Not a morning person but trying to smile2-14 At my favourite heal\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1553
  },
  {
    "id": "softlife-05",
    "category": "softlife",
    "categoryLabel": "Soft Life",
    "file": "softlife-05.jpg",
    "caption": "IN JPEGS1-14 Not a morning person but trying to smile2-14 At my favourite heal\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "softlife-06",
    "category": "softlife",
    "categoryLabel": "Soft Life",
    "file": "softlife-06.jpg",
    "caption": "IN JPEGS1-14 Not a morning person but trying to smile2-14 At my favourite heal\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "softlife-07",
    "category": "softlife",
    "categoryLabel": "Soft Life",
    "file": "softlife-07.jpg",
    "caption": "IN JPEGS1-14 Not a morning person but trying to smile2-14 At my favourite heal\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1553
  },
  {
    "id": "softlife-08",
    "category": "softlife",
    "categoryLabel": "Soft Life",
    "file": "softlife-08.jpg",
    "caption": "IN JPEGS1-14 Not a morning person but trying to smile2-14 At my favourite heal\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "softlife-09",
    "category": "softlife",
    "categoryLabel": "Soft Life",
    "file": "softlife-09.jpg",
    "caption": "IN JPEGS1-14 Not a morning person but trying to smile2-14 At my favourite heal\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "softlife-10",
    "category": "softlife",
    "categoryLabel": "Soft Life",
    "file": "softlife-10.jpg",
    "caption": "IN JPEGS1-14 Not a morning person but trying to smile2-14 At my favourite heal\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1553
  },
  {
    "id": "softlife-11",
    "category": "softlife",
    "categoryLabel": "Soft Life",
    "file": "softlife-11.jpg",
    "caption": "IN JPEGS1-14 Not a morning person but trying to smile2-14 At my favourite heal\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "softlife-12",
    "category": "softlife",
    "categoryLabel": "Soft Life",
    "file": "softlife-12.jpg",
    "caption": "IN JPEGS1-14 Not a morning person but trying to smile2-14 At my favourite heal\u2026",
    "orientation": "portrait",
    "w": 1086,
    "h": 1448
  },
  {
    "id": "transition-01",
    "category": "transition",
    "categoryLabel": "2025 / 2026",
    "file": "transition-01.jpg",
    "caption": ", HELLO 2026Wrapping up the year 2025 with these beautiful pics\u2026let me be the firs\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "transition-02",
    "category": "transition",
    "categoryLabel": "2025 / 2026",
    "file": "transition-02.jpg",
    "caption": ", HELLO 2026Wrapping up the year 2025 with these beautiful pics\u2026let me be the firs\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "transition-03",
    "category": "transition",
    "categoryLabel": "2025 / 2026",
    "file": "transition-03.jpg",
    "caption": ", HELLO 2026Wrapping up the year 2025 with these beautiful pics\u2026let me be the firs\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "vlogs-01",
    "category": "vlogs",
    "categoryLabel": "Vlogs",
    "file": "vlogs-01.jpg",
    "caption": "- MEMORIES 12-12As someone who would share a million videos before posting 1 picture, it\u2019\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "vlogs-02",
    "category": "vlogs",
    "categoryLabel": "Vlogs",
    "file": "vlogs-02.jpg",
    "caption": "- MEMORIES 12-12As someone who would share a million videos before posting 1 picture, it\u2019\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  },
  {
    "id": "vlogs-03",
    "category": "vlogs",
    "categoryLabel": "Vlogs",
    "file": "vlogs-03.jpg",
    "caption": "- MEMORIES 12-12As someone who would share a million videos before posting 1 picture, it\u2019\u2026",
    "orientation": "portrait",
    "w": 1170,
    "h": 1560
  }
];
